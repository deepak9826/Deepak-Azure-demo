package com.restapi.restbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
